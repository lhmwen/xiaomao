package com.lihuaxiaomao.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lihuaxiaomao.app.data.database.AppDatabase
import com.lihuaxiaomao.app.data.entity.Note
import com.lihuaxiaomao.app.data.entity.NoteGroup
import com.lihuaxiaomao.app.data.repository.NoteRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class NoteViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = NoteRepository(database.noteDao(), database.noteGroupDao())

    private val _noteGroups = MutableStateFlow<List<NoteGroup>>(emptyList())
    val noteGroups: StateFlow<List<NoteGroup>> = _noteGroups.asStateFlow()

    private val _notesWithoutGroup = MutableStateFlow<List<Note>>(emptyList())
    val notesWithoutGroup: StateFlow<List<Note>> = _notesWithoutGroup.asStateFlow()

    init {
        viewModelScope.launch {
            repository.getAllNoteGroups().collect {
                _noteGroups.value = it
            }
        }
        
        viewModelScope.launch {
            repository.getNotesWithoutGroup().collect {
                _notesWithoutGroup.value = it
            }
        }
    }

    fun createNote(title: String, content: String, groupId: String? = null) {
        viewModelScope.launch {
            repository.createNote(title, content, groupId)
        }
    }

    fun createNoteGroup(name: String) {
        viewModelScope.launch {
            repository.createNoteGroup(name)
        }
    }

    fun updateNote(note: Note) {
        viewModelScope.launch {
            repository.updateNote(note)
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch {
            repository.deleteNote(note)
        }
    }
}