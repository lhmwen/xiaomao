package com.lihuaxiaomao.app.data.dao

import androidx.room.*
import com.lihuaxiaomao.app.data.entity.NoteGroup
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteGroupDao {
    @Query("SELECT * FROM note_groups ORDER BY sortOrder ASC")
    fun getAllNoteGroups(): Flow<List<NoteGroup>>

    @Query("SELECT * FROM note_groups WHERE id = :id")
    suspend fun getNoteGroupById(id: String): NoteGroup?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNoteGroup(noteGroup: NoteGroup)

    @Update
    suspend fun updateNoteGroup(noteGroup: NoteGroup)

    @Delete
    suspend fun deleteNoteGroup(noteGroup: NoteGroup)

    @Query("UPDATE note_groups SET sortOrder = :sortOrder WHERE id = :id")
    suspend fun updateNoteGroupSortOrder(id: String, sortOrder: Int)
}