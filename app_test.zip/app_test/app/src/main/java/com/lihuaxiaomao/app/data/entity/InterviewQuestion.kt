package com.lihuaxiaomao.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "interview_questions")
data class InterviewQuestion(
    @PrimaryKey
    val id: String,
    val question: String,
    val answer: String,
    val groupId: String,
    val sortOrder: Int,
    val createdAt: Date,
    val updatedAt: Date
)