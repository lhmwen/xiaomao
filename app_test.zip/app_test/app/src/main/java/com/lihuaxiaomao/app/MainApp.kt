package com.lihuaxiaomao.app

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Note
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.lihuaxiaomao.app.ui.screen.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val bottomNavItems = listOf(
        BottomNavItem("notes", stringResource(R.string.notes), Icons.Default.Note),
        BottomNavItem("interview", stringResource(R.string.interview), Icons.Default.Quiz),
        BottomNavItem("documents", stringResource(R.string.documents), Icons.Default.Description),
        BottomNavItem("images", stringResource(R.string.images), Icons.Default.Image)
    )

    Scaffold(
        bottomBar = {
            // 只在主页面显示底部导航栏
            if (currentDestination?.route in bottomNavItems.map { it.route }) {
                NavigationBar {
                    bottomNavItems.forEach { item ->
                        NavigationBarItem(
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                            selected = currentDestination?.hierarchy?.any { it.route == item.route } == true,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "notes",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("notes") {
                NoteScreen(
                    onNavigateToGroup = { groupId, groupName ->
                        navController.navigate("note_detail/$groupId/$groupName")
                    },
                    onNavigateToUngrouped = {
                        navController.navigate("note_detail/null/无分组笔记")
                    }
                )
            }
            composable("note_detail/{groupId}/{groupName}") { backStackEntry ->
                val groupIdStr = backStackEntry.arguments?.getString("groupId")
                val groupId = if (groupIdStr == "null") null else groupIdStr?.toLongOrNull()
                val groupName = backStackEntry.arguments?.getString("groupName") ?: ""
                
                NoteDetailScreen(
                    groupId = groupId,
                    groupName = groupName,
                    onBackClick = { navController.popBackStack() }
                )
            }
            composable("interview") {
                InterviewScreen(
                    onNavigateToGroup = { groupId, groupName ->
                        navController.navigate("interview_detail/$groupId/$groupName")
                    }
                )
            }
            composable("interview_detail/{groupId}/{groupName}") { backStackEntry ->
                val groupId = backStackEntry.arguments?.getString("groupId")?.toLongOrNull() ?: 0L
                val groupName = backStackEntry.arguments?.getString("groupName") ?: ""
                
                InterviewDetailScreen(
                    groupId = groupId,
                    groupName = groupName,
                    onBackClick = { navController.popBackStack() }
                )
            }
            composable("documents") {
                DocumentScreen()
            }
            composable("images") {
                ImageScreen()
            }
        }
    }
}

data class BottomNavItem(
    val route: String,
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)