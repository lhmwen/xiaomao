package com.lihuaxiaomao.app.ui.screen

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lihuaxiaomao.app.data.entity.InterviewGroup
import com.lihuaxiaomao.app.ui.viewmodel.InterviewViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InterviewScreen(
    onNavigateToGroup: (Long, String) -> Unit = { _, _ -> },
    viewModel: InterviewViewModel = viewModel()
) {
    val interviewGroups by viewModel.interviewGroups.collectAsState()
    var showCreateGroupDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("面试题", fontSize = 20.sp, fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateGroupDialog = true }
            ) {
                Icon(Icons.Default.Add, contentDescription = "创建面试题组")
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(interviewGroups) { group ->
                    InterviewGroupCard(
                        group = group,
                        onClick = { onNavigateToGroup(group.id, group.name) },
                        onEdit = { /* TODO: 实现编辑功能 */ },
                        onDelete = { viewModel.deleteInterviewGroup(it) }
                    )
                }
            
            if (interviewGroups.isEmpty()) {
                item {
                    EmptyStateCard(
                        title = "还没有面试题组",
                        description = "点击右下角的 + 按钮创建你的第一个面试题组",
                        icon = Icons.Default.Quiz
                    )
                }
            }
        }
    }

    if (showCreateGroupDialog) {
        CreateInterviewGroupDialog(
            onDismiss = { showCreateGroupDialog = false },
            onConfirm = { name ->
                viewModel.createInterviewGroup(name)
                showCreateGroupDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InterviewGroupCard(
    group: com.lihuaxiaomao.app.data.entity.InterviewGroup,
    onClick: () -> Unit,
    onEdit: (com.lihuaxiaomao.app.data.entity.InterviewGroup) -> Unit,
    onDelete: (com.lihuaxiaomao.app.data.entity.InterviewGroup) -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.Quiz,
                contentDescription = null,
                modifier = Modifier.size(32.dp),
                tint = MaterialTheme.colorScheme.secondary
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = group.name,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "面试题组",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            
            Row {
                TextButton(onClick = { onEdit(group) }) {
                    Text("编辑")
                }
                TextButton(onClick = { onDelete(group) }) {
                    Text("删除")
                }
            }
        }
    }
}

@Composable
fun CreateInterviewGroupDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var name by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("创建面试题组") },
        text = {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("组名") },
                placeholder = { Text("例如：Java基础、算法、HR面试") },
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(name) },
                enabled = name.isNotBlank()
            ) {
                Text("创建")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("取消")
            }
        }
    )
}