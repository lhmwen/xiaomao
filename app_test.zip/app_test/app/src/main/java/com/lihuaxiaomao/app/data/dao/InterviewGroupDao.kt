package com.lihuaxiaomao.app.data.dao

import androidx.room.*
import com.lihuaxiaomao.app.data.entity.InterviewGroup
import kotlinx.coroutines.flow.Flow

@Dao
interface InterviewGroupDao {
    @Query("SELECT * FROM interview_groups ORDER BY sortOrder ASC")
    fun getAllInterviewGroups(): Flow<List<InterviewGroup>>

    @Query("SELECT * FROM interview_groups WHERE id = :id")
    suspend fun getInterviewGroupById(id: String): InterviewGroup?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInterviewGroup(interviewGroup: InterviewGroup)

    @Update
    suspend fun updateInterviewGroup(interviewGroup: InterviewGroup)

    @Delete
    suspend fun deleteInterviewGroup(interviewGroup: InterviewGroup)

    @Query("UPDATE interview_groups SET sortOrder = :sortOrder WHERE id = :id")
    suspend fun updateInterviewGroupSortOrder(id: String, sortOrder: Int)
}