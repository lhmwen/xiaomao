package com.lihuaxiaomao.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "documents")
data class Document(
    @PrimaryKey
    val id: String,
    val name: String,
    val filePath: String,
    val fileType: String,
    val fileSize: Long,
    val sortOrder: Int,
    val createdAt: Date,
    val updatedAt: Date
)